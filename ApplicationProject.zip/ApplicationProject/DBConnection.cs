﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;


namespace WpfApp
{
    public class DBConnection
    {
        private string databaseName;
        private MySqlConnection connection;

        
        private DBConnection(string _databaseName)
        {
            databaseName = _databaseName;
        }

        private static DBConnection _instance = null;
        public static DBConnection Instance(string _databaseName)
        {
            if (_instance == null)
            {
                _instance = new DBConnection(_databaseName);
            }
            return _instance;
        }

        public bool IsConnect()
        {
            if (connection == null)
            {
                if (String.IsNullOrEmpty(databaseName))
                {
                    return false;
                }
                string connectionString = string.Format("server=127.0.0.1;user=root;database={0};port=3306;password=; Convert Zero Datetime=True", databaseName);
                connection = new MySqlConnection(connectionString);
                connection.Open();
            }
            return true;
        }

        public void ExecuteQueries(string cmdText)//not injection safe?
        {
            MySqlCommand cmd = new MySqlCommand(cmdText, connection);
            cmd.ExecuteNonQuery();
        }

        public MySqlDataReader DataReader(string query)
        {
            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            while (dataRead.Read())
            {
                Console.WriteLine(dataRead.GetString(0));
            }
            return dataRead;
        }

        public MySqlDataReader DataReader(string query, string columnName)
        {
            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            while (dataRead.Read())
            {
                Console.WriteLine(dataRead.GetString(columnName));
            }
            return dataRead;
        }

        public MySqlDataReader DataReader(string query, int numOfColumns)
        {
            MySqlCommand cmd = new MySqlCommand(query, connection);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            while (dataRead.Read())
            {

                for (int i = 0; i < numOfColumns; i++)
                {
                    Console.Write(dataRead.GetString(i) + " ");
                }
                Console.WriteLine();
            }
            return dataRead;
        }

        public string GetUserEmail(string _email)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM USER WHERE Email = @_email ", connection);
            cmd.Parameters.AddWithValue("@_email", _email);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string retStr = dataRead.GetString(5);
            dataRead.Close();
            return retStr;
        }

        public string GetUserPassword(string _email)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM USER WHERE Email = @_email", connection);
            cmd.Parameters.AddWithValue("@_email", _email);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string retStr = dataRead.GetString(7);
            dataRead.Close();
            return retStr;
        }

        public string GetUserLevel(string _email)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM USER WHERE Email = @_email;", connection);
            cmd.Parameters.AddWithValue("@_email", _email);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string retStr = dataRead.GetString(1);
            dataRead.Close();
            return retStr;
        }

        public string[] GetEventData(int _eventId)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            string[] retStr = new string[9];
            for(int i = 0; i < 10; i++)
            {
                if(dataRead.Read())
                    retStr[i] = dataRead.GetString(i);
            }
            dataRead.Close();
            return retStr;
        }

        public string GetUsersOrganization(string _email)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM USER WHERE Email = @_email", connection);
            cmd.Parameters.AddWithValue("@_email", _email);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string retStr = dataRead.GetString(8);
            dataRead.Close();
            return retStr;
        }

        public string GetEventOrganization(int _eventId)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT WHERE EventId = @_eventId", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string retStr = dataRead.GetString(8);
            dataRead.Close();
            return retStr;
        }

        public string GetEventMaxParticipants(int _eventId)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();
            string ret = dataRead.GetString(6);
            dataRead.Close();
            return ret;
        }

        public string GetEventParticipants(int _eventId)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            MySqlDataReader dataRead = cmd.ExecuteReader();
            dataRead.Read();

            if (dataRead.IsDBNull(7))
            {
                dataRead.Close();
                MySqlCommand c = new MySqlCommand("UPDATE EVENT SET NumberOfParticipants = 1 WHERE EventId = @_eventId;", connection);
                c.Parameters.AddWithValue("@_eventId", _eventId);
                c.ExecuteNonQuery();
                return "1";
            }
            else
            {
                string ret = dataRead.GetString(7);
                dataRead.Close();
                return ret;
            }
        }

        public bool AddOneToEventParticipants(int _eventId)
        {
            try
            {
                if (Convert.ToInt32(GetEventMaxParticipants(_eventId)) > Convert.ToInt32(GetEventParticipants(_eventId)))
                {
                    int newMax = Convert.ToInt32(GetEventParticipants(_eventId));
                    MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET NumberOfParticipants = @newMax WHERE EventId = @_eventId;", connection);
                    newMax++;
                    cmd.Parameters.AddWithValue("@newMax", newMax);
                    cmd.Parameters.AddWithValue("@_eventId", _eventId);
                    cmd.ExecuteNonQuery();
                    return true;
                }
                else return false;
            }
            catch (NullReferenceException)
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET NumberOfParticipants = 1 WHERE EventId = @_eventId;", connection);
                cmd.ExecuteNonQuery();
                return true;
            }
            
        }

        public bool CreateNewUser(string _email, string _name, string _pass, string _phoneNum, string _address)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("INSERT INTO USER (UserLevel, Name, Address, Email, Phonenumber, slowHashSalt) values (0, @_name, @_address, @_email, @_phonenum, @_pass);", connection); // registerEmail, registerName, registerPass, registerPhoneNum, registerAddress
                cmd.Parameters.AddWithValue("@_name", _name);
                cmd.Parameters.AddWithValue("@_address", _address);
                cmd.Parameters.AddWithValue("@_email", _email);
                cmd.Parameters.AddWithValue("@_phonenum", _phoneNum);
                cmd.Parameters.AddWithValue("@_pass", _pass);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }            
        }

        public bool CreateNewEvent(string _eventName, string _eventDescription, int _eventOrganizationId, int _maxParticipants, DateTime _sDate, DateTime _eDate, string _specialistKeywords, string _targetKeywords, int _locationId)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("INSERT INTO EVENT (Name, DescOfEvent, Location_Id, StartDate, EndDate, MaxParticipants, OrganizationId, EventIsVisible, SpecialistKeywords, TargetGroupKeywords) values (@_eventName, @_eventDescription, @_locationId, @_sDate, @_eDate, @_maxParticipants, @_eventOrganizationId, 'Yes', @_specialistKeywords, @_targetKeywords);", connection); 
                cmd.Parameters.AddWithValue("@_eventName", _eventName);
                cmd.Parameters.AddWithValue("@_eventDescription", _eventDescription);
                cmd.Parameters.AddWithValue("@_locationId", _locationId);
                cmd.Parameters.AddWithValue("@_sDate", _sDate.ToString("yyyy-MM-dd H:mm:ss"));
                cmd.Parameters.AddWithValue("@_eDate", _eDate.ToString("yyyy-MM-dd H:mm:ss"));
                cmd.Parameters.AddWithValue("@_maxParticipants", _maxParticipants);
                cmd.Parameters.AddWithValue("@_eventOrganizationId", _eventOrganizationId);
                cmd.Parameters.AddWithValue("@_specialistKeywords", _specialistKeywords);
                cmd.Parameters.AddWithValue("@_targetKeywords", _targetKeywords);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ModifyEvent(string _eventName, string _eventDescription, int _eventOrganizationId, int _maxParticipants, DateTime _sDate, DateTime _eDate, int _eventId)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET Name = _@eventName, DescOfEvent = @_eventdescription, StartDate = @_sDate, EndDate = @_endDate, MaxParticipants = @_maxParticipants WHERE  EventId = @_event_id;", connection);
                cmd.Parameters.AddWithValue("@_eventName", _eventName);
                cmd.Parameters.AddWithValue("@_eventDescription", _eventDescription);
                cmd.Parameters.AddWithValue("@_sDate", _sDate.ToString("yyyy-MM-dd H:mm:ss"));
                cmd.Parameters.AddWithValue("@_eDate", _eDate.ToString("yyyy-MM-dd H:mm:ss"));
                cmd.Parameters.AddWithValue("@_maxParticipants", _maxParticipants);
                cmd.Parameters.AddWithValue("@_eventId", _eventId);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void DeleteEvent(int _eventId) 
        {
            MySqlCommand cmd = new MySqlCommand("DELETE FROM EVENT WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }

        public void HideEvent(int _eventId)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE Event SET EventIsVisible = 'No' WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserLevel(string _email, int newUserLevel) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET UserLevel = @newUserLevel WHERE Email = @_email;", connection);
            cmd.Parameters.AddWithValue("@_email", _email);
            cmd.Parameters.AddWithValue("@newUserLevel", newUserLevel);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserLevel(int _uid, int newUserLevel) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET UserLevel = @newUserLevel WHERE UserId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newUserLevel", newUserLevel);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserEmail(int _uid, string newUserEmail) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET Email = @newUserEmail WHERE UserId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newUserEmail", newUserEmail);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserAddress(int _uid, string newUserAddress) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET Address = @newUseraddress WHERE UserId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newUserAddress", newUserAddress);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserPhoneNumber(int _uid, int newUserNum) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET PhoneNumber = @newUserNum WHERE UserId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newUserNum", newUserNum);
            cmd.ExecuteNonQuery();
        }

        public void ChangeLocationId(int _uid, int newLocationId) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE Event SET Location_Id = @newLocationId WHERE EventId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newLocationId", newLocationId);
            cmd.ExecuteNonQuery();
        }

        public void ChangeSpecialistKeywords(int _uid, string newKeywords) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET SpecialistKeywords = @newKeywords WHERE EventId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newKeywords", newKeywords);
            cmd.ExecuteNonQuery();
        }

        public void ChangeTargetKeywords(int _uid, string newKeywords) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET TargetGroupKeywords = @newKeywords WHERE EventId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@newKeywords", newKeywords);
            cmd.ExecuteNonQuery();
        }

        public void ChangeUserToOrganizationRepresentative(int _uid, int orgId) // user who call this has to have userlevel 2 or higher
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET RepresentsOrganization = @orgId WHERE UserId = @_uid;", connection);
            cmd.Parameters.AddWithValue("@_uid", _uid);
            cmd.Parameters.AddWithValue("@orgId", orgId);
            cmd.ExecuteNonQuery();
        }

        public void AddOrganizationRepresentative(string _email, int _organizationId) // automatically increases userlevel to 1 if it is not already
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE USER SET RepresentsOrganization = @_organizationId WHERE Email = @_email;", connection);
            cmd.Parameters.AddWithValue("@_organizationId", _organizationId);
            cmd.Parameters.AddWithValue("@_email", _email);
            cmd.ExecuteNonQuery();

            if(GetUserLevel(_email) == "0") // changes only if user level == 0, cant accidentally change userlevel from 2 to 1
            {
                ChangeUserLevel(_email, 1);
            }
        }
        public string SearchEngine(string search)
        {

            return string.Format("DescOfEvent LIKE '%{0}%' OR Name LIKE '%{0}%' OR SpecialistKeywords LIKE '%{0}%' OR TargetGroupKeywords LIKE '%{0}%'", search);

        }
        public DataTable ShowEvents()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT;", connection);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable("Event");
            adp.Fill(dt);
            return dt;
        }
        public DataTable ShowVisibleEvents()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM EVENT WHERE EventIsVisible = 'Yes';", connection);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable("Event");
            adp.Fill(dt);
            return dt;
        }
        public DataTable ShowAllUsers()
        {
            MySqlCommand cmd = new MySqlCommand("SELECT UserId, UserLevel, Name, Address, Preference, Email, Phonenumber FROM USER;", connection);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable("Event");
            adp.Fill(dt);
            return dt;
        }
        public DataTable ShowEventDates(DateTime _start, DateTime _end)
        {
            // MySqlCommand cmd = new MySqlCommand("SELECT * FROM event WHERE (StartDate BETWEEN '@_start' AND '@_end')", connection);
            MySqlCommand cmd = new MySqlCommand("select * from event where(startdate between @_start and @_end);", connection);
            cmd.Parameters.AddWithValue("@_start", _start);
            cmd.Parameters.AddWithValue("@_end", _end);
            cmd.ExecuteNonQuery();

            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable("EventDates");
            adp.Fill(dt);
            return dt;
        }
        public DataTable ShowEventWithLocationId(int locationId)
        {
            MySqlCommand cmd = new MySqlCommand("select * from event where Location_Id = @locationId;", connection);
            cmd.Parameters.AddWithValue("@locationId", locationId);
            cmd.ExecuteNonQuery();

            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable("EventLocations");
            adp.Fill(dt);
            return dt;
        }
        public void Close()
        {
            connection.Close();
            Console.WriteLine("Disconnected");
        }

        public void ChangeEventName(int _eventId, string _eventName)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET Name = @_EventName WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_EventName", _eventName);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }

        public void ChangeStartDate(int _eventId, DateTime _sDate)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET StartDate = @_sDate WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_sDate", _sDate);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }

        public void ChangeEndDate(int _eventId, DateTime _eDate)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET EndDate = @_eDate WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eDate", _eDate);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }

        public void ChangeEventDescription(int _eventId, string _eventDescription)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET DescOfEvent = @_eventDescription WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventDescription", _eventDescription);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }
        
        public void ChangeMaxParticipants(int _eventId, int _eventMaxParticipants)
        {
            MySqlCommand cmd = new MySqlCommand("UPDATE EVENT SET MaxParticipants = @_eventMaxParticipants WHERE EventId = @_eventId;", connection);
            cmd.Parameters.AddWithValue("@_eventMaxParticipants", _eventMaxParticipants);
            cmd.Parameters.AddWithValue("@_eventId", _eventId);
            cmd.ExecuteNonQuery();
        }
    }
}
