﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace WpfApp
{
    public class AppEngine
    {
        protected DBConnection con;
        int currentlyUsingUserLevel;

        public AppEngine()
        { 
           con = DBConnection.Instance("AppProject");
        }

        public void Start()
        {
            DBConnection connection = DBConnection.Instance("AppProject");
            if (connection.IsConnect())
            {
                Console.WriteLine("Connected");
            }
        }

        public bool CheckEmailAndPass(string _email, string _password)
        {
            string password = con.GetUserPassword(_email);
            bool validPassword = PasswordStorage.VerifyPassword(_password, password);

            if (_email == con.GetUserEmail(_email) && validPassword == true && con.GetUserEmail(_email) != null)
            {
                return true;
            }
            else return false;
        }

        public string ReturnUserLvl(string _email)
        {
            return con.GetUserLevel(_email);
        }
        public DataTable ShowAllEvent()
        {
            return con.ShowEvents();
        }

        public DataTable ShowVisibleEvents()
        {
            return con.ShowVisibleEvents();
        }
        public bool EventDeleter(int deleteEventId)
        {
            try
            {
                con.DeleteEvent(deleteEventId);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool EventHider(int hideEventId)
        {
            try
            {
                con.HideEvent(hideEventId);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool UserRepresentsOrganization(int eventId, string userEmail)
        {
            if (con.GetUsersOrganization(userEmail) == con.GetEventOrganization(eventId)) return true;
            else return false;
        }

        //public bool EventModifyer(int _eventId, string[] _newData)
        //{
        //    string[] eventData = con.GetEventData(_eventId);

        //    for(int i = 0; i < eventData.Length; i++)
        //    {
        //        if (_newData[i] != null)
        //            eventData[i] = _newData[i];
        //    }

        //    Event eventToModify = new Event(eventData[1], eventData[2], Convert.ToInt32(eventData[3]), Convert.ToInt32(eventData[6]), DateTime.Parse(eventData[4]), DateTime.Parse(eventData[5])); // eh...
        //    eventToModify.AddEvent();

        //    return true;
        //}

        public bool ChangeEventName(int _eventId, string _eventName)
        {
            con.ChangeEventName(_eventId, _eventName);
            return true;
        }
        public string Search(string search)
        {
            return con.SearchEngine(search);
        }
        public bool ChangeEventStartDate(int _eventId, DateTime _eventSDate)
        {
            con.ChangeStartDate(_eventId, _eventSDate);
            return true;
        }

        public bool ChangeEventEndDate(int _eventId, DateTime _eventEndDate)
        {
            con.ChangeEndDate(_eventId, _eventEndDate);
            return true;
        }

        public bool ChangeEventMaxParticipants(int _eventId, int _maxParticipants)
        {
            con.ChangeMaxParticipants(_eventId, _maxParticipants);
            return true;
        }

        public bool ChangeEventDescription(int _eventId, string _eventDescription)
        {
            con.ChangeEventDescription(_eventId, _eventDescription);
            return true;
        }

        public bool ChangeUserLvl(int id, int newlvl)
        {
            con.ChangeUserLevel(id, newlvl);
            return true;
        }

        public bool ChangeUserEmail(int id, string newMail)
        {
            con.ChangeUserEmail(id, newMail);
            return true;
        }

        public bool ChangeUserAddress(int id, string newAddress)
        {
            con.ChangeUserAddress(id, newAddress);
            return true;
        }

        public bool ChangeUserPhoneNumber(int id, int newNum)
        {
            con.ChangeUserPhoneNumber(id, newNum);
            return true;
        }

        public bool ChangeSpecialistKeywords(int id, string keywords)
        {
            con.ChangeSpecialistKeywords(id, keywords);
            return true;
        }

        public bool ChangeTargetKeywords(int id, string keywords)
        {
            con.ChangeTargetKeywords(id, keywords);
            return true;
        }

        public bool ChangeLocationId(int id, int _locationId)
        {
            con.ChangeLocationId(id, _locationId);
            return true;
        }

        public bool UserRepresentsOrganization(int id, int orgId)
        {
            con.ChangeUserToOrganizationRepresentative(id, orgId);
            return true;
        }

        public void JoinEvent(int eventId)
        {
            con.AddOneToEventParticipants(eventId);
        }
        public DataTable ShowEventDate(DateTime _start, DateTime _end)
        {
            return con.ShowEventDates(_start, _end);
        }
        public DataTable ShowEventLocation(int locationId)
        {
            return con.ShowEventWithLocationId(locationId);
        }
        public DataTable ShowAllUsers()
        {
            return con.ShowAllUsers();
        }
    }

    

}
