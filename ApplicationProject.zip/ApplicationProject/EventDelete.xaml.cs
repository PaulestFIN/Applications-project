﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for EventDelete.xaml
    /// </summary>
    public partial class EventDelete : Window
    {
        protected int deleteId;
        private int userLevelCheck;

        public EventDelete()
        {
            InitializeComponent();
        }

        private void DeleteEventId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            deleteId = Convert.ToInt32(DeleteEventId.Text);
            AppEngine delete = new AppEngine();

            if (delete.CheckEmailAndPass(Email.Text, Password.Password.ToString()))
            {
                userLevelCheck = Convert.ToInt32(delete.ReturnUserLvl(Email.Text));
            }

            switch(userLevelCheck)
            {
                case 0:
                    MessageBox.Show("You dont have high enough user level to delete events");
                    break;
                case 1:
                    if (delete.UserRepresentsOrganization(deleteId, Email.Text))
                    {
                        if (delete.EventDeleter(deleteId))
                        {
                            MessageBox.Show("Event with an id {0} deleted permanently", deleteId.ToString());
                        }
                        else
                            MessageBox.Show("Something went wrong!");
                    }
                    else
                        MessageBox.Show("You can only delete events from organization that you represent.");
                    break;
                case 2:
                    if (delete.EventDeleter(deleteId))
                    {
                        MessageBox.Show("Event with an id {0} deleted permanently", deleteId.ToString());  
                    }
                    else
                        MessageBox.Show("Something went wrong!");
                        break;
                default:
                    break;
            }
            this.Close();
        }

        private void Password_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Email_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
