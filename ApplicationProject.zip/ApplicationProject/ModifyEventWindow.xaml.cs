﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for ModifyEventWindow.xaml
    /// </summary>
    public partial class ModifyEventWindow : Window
    {
        string eventName;
        int eventOrganizationId;
        DateTime sDate;
        DateTime eDate;
        int maxParticipants;
        string eventDescription;
        AppEngine newEvent;
        int eventId;
        string specialistKeywords;
        string targetGroupKeywords;
        int locationId;
        AppEngine modify = new AppEngine();
        private int userLevelCheck;

        public ModifyEventWindow()
        {
            InitializeComponent();
        }

        private void enterEventNameBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterDateBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterPhonenumberBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterAddresBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void enterEventIdBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterEndDateBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
           
            try
            {
                if (modify.CheckEmailAndPass(Email.Text, Password.Password.ToString()))
                {
                    userLevelCheck = Convert.ToInt32(modify.ReturnUserLvl(Email.Text));

                    if (userLevelCheck == 2 || modify.UserRepresentsOrganization(Convert.ToInt32(enterEventIdBox.Text), Email.Text))
                    {
                        if (enterEventIdBox.Text != string.Empty)
                        {
                            eventId = Convert.ToInt32(enterEventIdBox.Text);
                        }

                        if (enterEventNameBox.Text != string.Empty)
                        {
                            eventName = enterEventNameBox.Text;
                            modify.ChangeEventName(eventId, eventName);
                        }
                        if (enterDateBox.Text != string.Empty)
                        {
                            sDate = DateTime.Parse(enterDateBox.Text);
                            modify.ChangeEventStartDate(eventId, sDate);
                        }
                        if (enterEndDateBox.Text != string.Empty)
                        {
                            eDate = DateTime.Parse(enterEndDateBox.Text);
                            modify.ChangeEventEndDate(eventId, eDate);
                        }
                        if (maxParticipantsBox.Text != string.Empty)
                        {
                            maxParticipants = Convert.ToInt32(maxParticipantsBox.Text);
                            modify.ChangeEventMaxParticipants(eventId, maxParticipants);
                        }
                        if (enterEventDescBox.Text != string.Empty)
                        {
                            eventDescription = enterEventDescBox.Text;
                            modify.ChangeEventDescription(eventId, eventDescription);
                        }
                        if (SpecialistKeywordsBox.Text != string.Empty)
                        {
                            specialistKeywords = SpecialistKeywordsBox.Text;
                            modify.ChangeSpecialistKeywords(eventId, specialistKeywords);

                        }
                        if (TargetGroupKeywordsBox.Text != string.Empty)
                        {
                            targetGroupKeywords = TargetGroupKeywordsBox.Text;
                            modify.ChangeTargetKeywords(eventId, targetGroupKeywords);
                        }
                        if (LocationIdBox.Text != string.Empty)
                        {
                            locationId = Convert.ToInt32(LocationIdBox.Text);
                            modify.ChangeLocationId(eventId, locationId);
                        }


                        MessageBox.Show("Event modified!");
                        this.Close();
                    }
                    else
                        MessageBox.Show("You can't modify this.");
                }
                else
                    MessageBox.Show("Wrong email or password");

            }
            catch
            {
                MessageBox.Show("Something went Wrong, try again!");
                //ModifyEventWindow modifyEvent = new ModifyEventWindow();
                //this.Close();
                //modifyEvent.ShowDialog();
            }
        }

        private void SpecialistKeywordBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TargetGroupKeywordsBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LocationIdBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Email_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
