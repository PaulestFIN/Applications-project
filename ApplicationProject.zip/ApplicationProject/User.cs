﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp
{
    public class User : AppEngine
    {
        public static int UserId = 0;
        int userLevel;
        string userName;
        string address;
        string preference;
        string email;
        string phonenumber;
        string password;


        public User()
        {
            UserId++;//maybe not needed
        }

        public User(string _email, string _name, string _pass, string _phoneNum, string _address) : this() // registerEmail, registerName, registerPass, registerPhoneNum, registerAddress
        {
            //userLevel = _userLevel;
            userName = _name;
            address = _address;
            email = _email;
            phonenumber = _phoneNum;
            password = _pass;

            con.CreateNewUser(email, userName, password, phonenumber, address);// kutsuu DB metodia CreateNewUser ja lisää databaseen uudet tiedot, userlvl default on 0, admin voi nostaa tietyn käyttäjän userlevelii?
        }


        public void ChangeUserLvl()//called from uiengine and calls a method from dbengine to edit a user
        {

        }
        public void ChangeAddress(string _address)
        {
            address = _address;
        }

        public void AddPreference()//called from uiengine and calls a method from dbengine to add/change a preference
        {

        }
        public void ChangeEmail(string _email)
        {
            email = _email;
        }
        public void ChangePhoneNumber(string _phoneNum)
        {
            phonenumber = _phoneNum;
        }
        public bool CheckEmailAndPass(DBConnection con, string _email, string _password)
        {
            string password = con.GetUserPassword(_email);
            bool validPassword = PasswordStorage.VerifyPassword(_password, password);

            if (_email == con.GetUserEmail(_email) && validPassword == true && con.GetUserEmail(_email) != null)
            {
                return true;
            }
            else return false;
        }
    }
}
