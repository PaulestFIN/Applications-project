﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AppEngine AppOlio;
        private DateTime _start;
        private DateTime end;

        public MainWindow()
        {
            AppOlio = new AppEngine();
            AppOlio.Start();
            InitializeComponent();
            Login loginwindow = new Login();
            loginwindow.ShowDialog();
        }

       



        private void ShowAllEventButton_Click(object sender, RoutedEventArgs e)
        {
                try
                {
                    DataTable dt_ = AppOlio.ShowVisibleEvents();
                    MainDataGrid.ItemsSource = dt_.DefaultView;
                }
                catch
                {
                    MessageBox.Show("Something went wrong");
                }
            
        }

        private void SearchEventBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                DataTable dt = AppOlio.ShowVisibleEvents();
                string search = searchEventBox.Text;
                DataView dv = new DataView(dt);
                dv.RowFilter = AppOlio.Search(search);
                MainDataGrid.ItemsSource = dv;
            }
            catch
            {
                MessageBox.Show("Something went wrong");
            }
        }

        private void ParticipateEventBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ParticipateEventButton_Click(object sender, RoutedEventArgs e)
        {
            int eventId = Convert.ToInt32(ParticipateEventBox.Text);
            AppOlio.JoinEvent(eventId);
        }

        private void StartDayBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EndDayBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SubmitDatesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string s = startDayBox.Text;
                string en = endDayBox.Text;


                _start = DateTime.Parse(s);
                end = DateTime.Parse(en);

                DataTable dt = AppOlio.ShowEventDate(_start, end);


                MainDataGrid.ItemsSource = dt.DefaultView;





            }
            catch
            {
                MessageBox.Show("Something went wrong");

            }
        }

        private void SearchLocationBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void SubmitLocationButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int locId = Convert.ToInt32(searchWithLocationBox.Text);
                DataTable dt = AppOlio.ShowEventLocation(locId);
                MainDataGrid.ItemsSource = dt.DefaultView;
            }
            catch
            {
                MessageBox.Show("Something went wrong");
            }
        }
    }
}
