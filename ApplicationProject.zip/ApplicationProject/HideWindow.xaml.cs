﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for HideWindow.xaml
    /// </summary>
    public partial class HideWindow : Window
    {
        protected int hideId;
        private int userLevelCheck;

        public HideWindow()
        {
            InitializeComponent();
        }

        private void ButtonHide_Click(object sender, RoutedEventArgs e)
        {
            hideId = Convert.ToInt32(HideEventId.Text);
            AppEngine hide = new AppEngine();

            if (hide.CheckEmailAndPass(Email.Text, Password.Password.ToString()))
            {
                userLevelCheck = Convert.ToInt32(hide.ReturnUserLvl(Email.Text));
            }

            if (userLevelCheck == 2 || hide.UserRepresentsOrganization(hideId, Email.Text))
            {
                hide.EventHider(hideId);
                MessageBox.Show("Event with an id {0} is now hidden!", hideId.ToString());
                this.Close();
            }

            else { MessageBox.Show("Something went wrong!"); }
        }

        private void HideEventId_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Email_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
