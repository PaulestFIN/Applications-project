﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for ModifyUserWindow.xaml
    /// </summary>
    public partial class ModifyUserWindow : Window
    {
        AppEngine modify = new AppEngine();
        int userId;
        int userlvl;
        string email;
        string address;
        int phonenumber;
        int repOrgId;

        public ModifyUserWindow()
        {
            InitializeComponent();
        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (UserIdBox.Text != string.Empty)
                {
                    userId = Convert.ToInt32(UserIdBox.Text);
                }

                if (enterUserLevelBox.Text != string.Empty)
                {
                    userlvl = Convert.ToInt32(enterUserLevelBox.Text);
                    if (userlvl > 2)
                        userlvl = 2;
                    if (userlvl < 0)
                        userlvl = 0;
                    if (enterUserLevelBox.Text == string.Empty)
                        userlvl = 0;

                    modify.ChangeUserLvl(userId, userlvl);
                }
                if (enterEmailBox.Text != string.Empty)
                {
                    email = enterEmailBox.Text;
                    modify.ChangeUserEmail(userId, email);
                }
                if (enterAddressBox.Text != string.Empty)
                {
                    address = enterAddressBox.Text;
                    modify.ChangeUserAddress(userId, address);
                }
                if (enterPhonenumberBox.Text != string.Empty)
                {
                    phonenumber = Convert.ToInt32(enterPhonenumberBox.Text);
                    modify.ChangeUserPhoneNumber(userId, phonenumber);
                }
                if (enterOrgIdBox.Text != string.Empty)
                {
                    repOrgId = Convert.ToInt32(enterOrgIdBox.Text);
                    if (UserIdBox.Text != string.Empty)
                    {
                        modify.UserRepresentsOrganization(userId, repOrgId);
                    }
                    else
                        MessageBox.Show("Insert Organization Id to do that");
                }

                MessageBox.Show("User modified!");
            }
            catch
            {
                MessageBox.Show("Something went Wrong!");
                ModifyUserWindow modifyUser = new ModifyUserWindow();
                this.Close();
                modifyUser.ShowDialog();
            }
        }
        private void UserIdBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterUserLevelBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterEmailBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void enterAddressBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterPhonenumberBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterOrgIdBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
