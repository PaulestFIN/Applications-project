﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for AddEvent.xaml
    /// </summary>
    public partial class AddEvent : Window
    {
        string eventName;
        int eventOrganizationId;
        DateTime sDate;
        DateTime eDate;
        int maxParticipants;
        string eventDescription;
        AppEngine newEvent;
        string specialistKeywords;
        string targetGroupKeywords;
        int locationId;

        public AddEvent()
        {
            InitializeComponent();
        }

        private void EnterDateBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void enterEventNameBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void enterOrganizationBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterPhonenumberBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterAddresBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                eventName = enterEventNameBox.Text;
                eventOrganizationId = Convert.ToInt32(enterOrganizationBox.Text);
                sDate = DateTime.Parse(enterDateBox.Text);
                eDate = DateTime.Parse(enterEndDateBox.Text);
                maxParticipants = Convert.ToInt32(maxParticipantsBox.Text);
                eventDescription = enterEventDescBox.Text;
                specialistKeywords = SpecialistKeywordsBox.Text;
                targetGroupKeywords = TargetGroupKeywordsBox.Text;
                locationId = Convert.ToInt32(LocationIdBox.Text);
            
                newEvent = new Event(eventName, eventDescription, eventOrganizationId, maxParticipants, sDate, eDate, specialistKeywords, targetGroupKeywords, locationId);
                MessageBox.Show("Event added!");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Something went Wrong!");
                AddEvent addWindow = new AddEvent();
                this.Close();
                
            }
        }

        private void EnterEndDateBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SpecialistKeywordBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TargetGroupKeywordsBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LocationIdBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
