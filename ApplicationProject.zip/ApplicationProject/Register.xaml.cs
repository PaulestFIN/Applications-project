﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        string registerEmail;
        string registerName;
        string registerPass;
        string registerPhoneNum;
        string registerAddress;
        AppEngine newUser;


        public Register()
        {            
            InitializeComponent();
        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            registerEmail = enterEmailBox.Text;
            registerName = enterNameBox.Text;
            //registerPass = enterPasswordBox.Password;
            registerPhoneNum = enterPhonenumberBox.Text;
            registerAddress = enterAddresBox.Text;

            string saltHashReturned = PasswordStorage.CreateHash(enterPasswordBox.Password);
            //int commaIndex = saltHashReturned.IndexOf(":");
            //string extractedString = saltHashReturned.Substring(0, commaIndex);
            //commaIndex = saltHashReturned.IndexOf(":");
            //extractedString = saltHashReturned.Substring(commaIndex + 1);
            //commaIndex = extractedString.IndexOf(":");
            //string salt = extractedString.Substring(0, commaIndex);
            //commaIndex = extractedString.IndexOf(":");
            //extractedString = extractedString.Substring(commaIndex + 1);
            //string hash = extractedString;
            // from the first : to the second : is the salt
            // from the second : to the end is the hash

            newUser = new User(registerEmail, registerName, saltHashReturned, registerPhoneNum, registerAddress);// tekee uuden objection user classiin

            MessageBox.Show("User added");
            this.Close();
        }

        private void EnterEmailBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterNameBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterPhonenumberBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void EnterAddresBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
