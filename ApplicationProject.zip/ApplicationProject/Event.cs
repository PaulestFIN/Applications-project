﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp
{
    public class Event : AppEngine
    {
        public static int eventID = 0;
        private string eventName;
        private string description;
        private DateTime startDate;
        private DateTime endDate;
        private int maxParticipants;
        private int numberOfParticipants;//mistä me saadaan tää luku?
        private int organizationId;
        private int locationId;
        private string organizationName;
        string specialistKeywords;
        string targetKeywords;
        //Automatic search for events from an area (locations now need to be grouped into areas) with possibility to filter according to event details (“customer view”). 
        //groupataan nää maakuntien mukaa nii et esim 1 = Päijät-Häme, 2 = Uusimaa, 3 = Varsinais-Suomi jnejne? sit vaa joku select * from event where locationId = 1 jos joku haluu kaikki eventit Päijät-Hämeestä

        //Repeating events i.e. events that happen weekly, monthly etc. within given time range
        //DateTime date = DateTime.Now;
        //TimeSpan time = new TimeSpan(36, 0, 0, 0);
        //DateTime combined = date.Add(time);
        //Console.WriteLine("{0:dddd}", combined);
        //^^?


        public Event(string _eventName, string _description, int _organizationId, int _maxParticipants, DateTime _sDate, DateTime _eDate, string _specialistKeywords, string _targetKeywords, int _locationId)//minimum req before event can be created?
        {
            eventName = _eventName;
            startDate = _sDate;
            endDate = _eDate;
            maxParticipants = _maxParticipants;
            description = _description;
            organizationId = _organizationId;
            specialistKeywords = _specialistKeywords;
            targetKeywords = _targetKeywords;
            locationId = _locationId;
            AddEvent();
        }

        public void AddEvent()
        {
            con.CreateNewEvent(eventName, description, organizationId, maxParticipants, startDate, endDate, specialistKeywords, targetKeywords, locationId);
        }

        public void ModifyEvent()
        {

        }

        public DateTime ChangeDate(DateTime date, int d, int m, int y)
        {
            return date = new DateTime(d, m, y);
        }
        public void ChangeEventName(string newName)
        {
            eventName = newName;
        }
        public void ChangeEventDescription(string newDesc)
        {
            description = newDesc;
        }
        public string GetName()
        {
            return eventName;
        }
        public string[] GetEventInfo()//doesnt work, maybe something to return an array of the event attributes
        {
            List<string> eventInfo = new List<string>();
            eventInfo.Add(eventID.ToString());
            return new string[2];
        }
        public void HideEvent()
        {
            //hides event
        }
        public void DeleteEvent()
        {
            //deletes event
        }
        public string[] GetEventsBetween(DateTime start, DateTime end)//Something to return events for a given time period
        {
            return new string[2];
        }
        public string[] GetEventsFromArea(int _locationId)
        {
            List<string> events = new List<string>();


            return new string[2];
        }

        
    }
}
