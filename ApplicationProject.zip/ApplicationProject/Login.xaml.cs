﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {

        protected string _email;
        protected string _password;
        protected AppEngine AppOlio2;
        public int CurrentlyUsingUserLevel { get; set; }


        public Login()
        {
            AppOlio2 = new AppEngine();
            

            InitializeComponent();
        }


        private void buttonLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (AppOlio2.CheckEmailAndPass(emailBox.Text, passwordBox.Password.ToString()) == true)
                {
                    CurrentlyUsingUserLevel = Convert.ToInt32(AppOlio2.ReturnUserLvl(emailBox.Text));

                    if (AppOlio2.ReturnUserLvl(emailBox.Text) == "0")
                    {                        
                        this.Close();                        
                    }

                    else if (AppOlio2.ReturnUserLvl(emailBox.Text)== "1")
                    {
                        MainWindowOrganization main2 = new MainWindowOrganization();
                        this.Close();
                        main2.ShowDialog();
                            
                    }

                    else if (AppOlio2.ReturnUserLvl(emailBox.Text)== "2")
                    {
                        AdminWindow aWindow = new AdminWindow();
                        this.Close();
                        aWindow.ShowDialog();
                    }
                }

                else
                {
                    MessageBox.Show("Wrong E-mail or password");
                }
            }
           catch
            {
                MessageBox.Show("Something went wrong");
            }
        }

       

        private void registerLogin_Click(object sender, RoutedEventArgs e)
        {
            Register window = new Register();
            this.Close();
            window.ShowDialog();
        }
    }
}
