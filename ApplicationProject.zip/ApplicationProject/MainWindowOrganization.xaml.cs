﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace WpfApp
{
    /// <summary>
    /// Interaction logic for MainWindowOrganization.xaml
    /// </summary>
    public partial class MainWindowOrganization : Window
    {
        protected AppEngine AppOlio;
        private DateTime _start;
        private DateTime end;

        public MainWindowOrganization()
        {
            AppOlio = new AppEngine();
            InitializeComponent();
        }

        private void AddEventButton_Click(object sender, RoutedEventArgs e)
        {
            AddEvent addWindow = new AddEvent();
            
            addWindow.ShowDialog();
        }

        private void ShowAllEventsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DataTable dt_ = AppOlio.ShowAllEvent();
                AdminDataGrid.ItemsSource = dt_.DefaultView;
            }
            catch
            {
                MessageBox.Show("Something went wrong");
            }
        }

        private void DeleteEventButton_Click(object sender, RoutedEventArgs e)
        {
            EventDelete deleteWindow = new EventDelete();
            deleteWindow.ShowDialog();
        }

        private void HideEventButton_Click(object sender, RoutedEventArgs e)
        {
            HideWindow hidewin = new HideWindow();
            hidewin.ShowDialog();
        }

        private void SearchEventBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                string search = searchEventBox.Text;
                DataTable dt = AppOlio.ShowAllEvent();
                DataView dv = new DataView(dt);
                dv.RowFilter = AppOlio.Search(search);
                AdminDataGrid.ItemsSource = dv;
            }
            catch
            {
                MessageBox.Show("Something went wrong");
            }
        }

        private void ModifyEventButton_Click(object sender, RoutedEventArgs e)
        {
            ModifyEventWindow modify = new ModifyEventWindow();
            modify.ShowDialog();
        }

        private void EndDayBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void StartDayBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SubmitDatesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string s = startDayBox.Text;
                string en = endDayBox.Text;


                _start = DateTime.Parse(s);
                end = DateTime.Parse(en);

                DataTable dt = AppOlio.ShowEventDate(_start, end);


                AdminDataGrid.ItemsSource = dt.DefaultView;





            }
            catch
            {
                MessageBox.Show("Something went wrong");

            }
        }

        private void SearchLocationBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void SubmitLocationButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int locId = Convert.ToInt32(searchWithLocationBox.Text);
                DataTable dt = AppOlio.ShowEventLocation(locId);
                AdminDataGrid.ItemsSource = dt.DefaultView;
            }
            catch
            {
                MessageBox.Show("Something went wrong");
            }
        }
    }
}
